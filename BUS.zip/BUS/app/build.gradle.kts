val implementation: Unit

plugins {
    id 'com.android.application'
}

android {
    namespace = "com.example.bus"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.bus"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {

    implementation 'androidx.appcompat:appcompat:1.6.1' // appcompat 라이브러리
    implementation 'com.google.android.material:material:1.9.0' // Material 디자인 컴포넌트
    implementation 'androidx.activity:activity:1.6.1' // Activity 관련 라이브러리
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4' // ConstraintLayout
    testImplementation 'junit:junit:4.13.2' // JUnit 테스트 라이브러리
    androidTestImplementation 'androidx.test.ext:junit:1.1.5' // 안드로이드 JUnit 확장
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1' // Espresso 테스트 라이브러리
    implementation 'com.squareup.okhttp3:okhttp:4.9.3' // OkHttp 라이브러리 추가
}
